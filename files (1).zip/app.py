import google.generativeai as genai
from flask import Flask, render_template, request, jsonify, session
from flask_cors import CORS
import os

app = Flask(__name__)
app.secret_key = os.urandom(24)
CORS(app)

GOOGLE_API_KEY = "AIzaSyA9rn6jB1p2jRiIro5t-5CP7vryO1PkZ28"
genai.configure(api_key=GOOGLE_API_KEY)

SYSTEM_PROMPT = """
És um assistente inteligente que ajuda utilizadores a descobrirem os cursos universitários mais adequados para eles. O teu objetivo é recomendar entre 1 e 3 cursos com base nas respostas do utilizador a perguntas simples.

Segue estas regras:
- Faz uma pergunta de cada vez.
- As perguntas devem ser claras, diretas e relevantes para perceber os interesses e aptidões do utilizador.
- Utiliza linguagem informal, acessível e amigável.
- Dá opções de resposta sempre que possível (ex.: “Sim / Não”, ou “A / B / C”).
- Baseia-te nas respostas para afunilar as opções e evitar perguntas desnecessárias.
- Quando tiveres informação suficiente, responde com:
    o Uma lista de 1 a 3 cursos recomendados.
    o Uma pequena explicação do porquê de cada recomendação.

Os cursos disponíveis são:
"Arquitetura"
"Arquitetura Paisagista"
"Ciência de Dados"
"Economia"
"Economia (ensino em Inglês)"
"Engenharia Aeroespacial"
"Engenharia Civil"
"Engenharia da Energia e Ambiente"
"Engenharia de Materiais"
"Engenharia de Micro e Nanotecnologias"
"Engenharia de Minas e Recursos Energéticos"
"Engenharia de Telecomunicações e Informática"
"Engenharia do Ambiente"
"Engenharia e Gestão Industrial"
"Engenharia Eletrónica"
"Engenharia Eletrotécnica e de Computadores"
"Engenharia Física"
"Engenharia Física Tecnológica"
"Engenharia Florestal e dos Recursos Naturais"
"Engenharia Geoespacial"
"Engenharia Informática"
"Engenharia Informática e de Computadores"
"Engenharia Mecânica"
"Engenharia Naval e Oceânica"
"Engenharia Química"
"Estatística Aplicada"
"Finanças (ensino em inglês)"
"Física"
"Gestão"
"Gestão (ensino em Inglês)"
"Gestão de Informação"
"Matemática"
"Matemática Aplicada"
"Matemática Aplicada à Economia e à Gestão"
"Matemática Aplicada à Gestão do Risco"
"Matemática Aplicada e Computação"
"Química"
"Química Aplicada"
"Química Tecnológica"
"Sistemas e Tecnologias de Informação"
"Tecnologias de Informação"

Começa por perguntar algo como:
"Olá eu sou o Uniportal e vou te ajudar a escolher o teu curso. Gostas mais de ciências, letras ou áreas criativas?"
"""

def get_chat():
    if "chat" not in session:
        model = genai.GenerativeModel(
            model_name="gemini-1.5-flash-latest",
            system_instruction=SYSTEM_PROMPT
        )
        chat = model.start_chat(history=[])
        session["history"] = []
    else:
        model = genai.GenerativeModel(
            model_name="gemini-1.5-flash-latest",
            system_instruction=SYSTEM_PROMPT
        )
        chat = model.start_chat(history=session["history"])
    return chat

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/message", methods=["POST"])
def message():
    data = request.json
    user_input = data.get("message")
    if "history" not in session:
        session["history"] = []
    model = genai.GenerativeModel(
        model_name="gemini-1.5-flash-latest",
        system_instruction=SYSTEM_PROMPT
    )
    chat = model.start_chat(history=session["history"])
    response = chat.send_message(user_input)
    # Update history
    session["history"].append({"role": "user", "parts": [user_input]})
    session["history"].append({"role": "model", "parts": [response.text]})
    session.modified = True
    return jsonify({"response": response.text})

@app.route("/api/reset", methods=["POST"])
def reset():
    session.pop("history", None)
    return jsonify({"response": "Sessão reiniciada."})

if __name__ == "__main__":
    app.run(debug=True)