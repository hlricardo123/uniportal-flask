document.addEventListener("DOMContentLoaded", function() {
    const chatBox = document.getElementById("chat-box");
    const chatForm = document.getElementById("chat-form");
    const userInput = document.getElementById("user-input");

    function appendMessage(sender, text) {
        const div = document.createElement("div");
        div.innerHTML = `<b>${sender}:</b> ${text}`;
        chatBox.appendChild(div);
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    // Mensagem inicial
    appendMessage("UniPortal", "Olá eu sou o Uniportal e vou te ajudar a escolher o teu curso. Gostas mais de ciências, letras ou áreas criativas?");

    chatForm.addEventListener("submit", function(e) {
        e.preventDefault();
        const message = userInput.value.trim();
        if (!message) return;
        appendMessage("Você", message);
        userInput.value = "";
        fetch("/api/message", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message })
        })
        .then(res => res.json())
        .then(data => {
            appendMessage("UniPortal", data.response);
        });
    });
});